package dataProviders.Skill_Analysis;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class Skill_Data_Reader {
	
	private static Properties properties;
	private final String propertyFilePath= "src//main//java//configuration//Skill_Analysis//Skill_Analysis.properties";

	
	public Skill_Data_Reader(){
		BufferedReader reader;
		try {
			reader = new BufferedReader(new FileReader(propertyFilePath));
			properties = new Properties();
			try {
				properties.load(reader);
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			throw new RuntimeException("Configuration.properties not found at " + propertyFilePath);
		}		
	}
	
//***********************************************************************************************************************//
	public static String getWorkman_Name(){
		String getWorkman_Name = properties.getProperty("Workman_Name");
		if(getWorkman_Name!= null) return getWorkman_Name;
		else throw new RuntimeException("Workman_Name not specified in the Configuration.properties file.");		
	}
//***********************************************************************************************************************//
	public static String getSkillDesciprion(){
		String getSkillDesciprion = properties.getProperty("getSkillDesciprion");
		if(getSkillDesciprion!= null) return getSkillDesciprion;
		else throw new RuntimeException("getSkillDesciprion not specified in the Configuration.properties file.");		
	}
	
	public static String getSkillType(){
		String getSkillType = properties.getProperty("getSkillType");
		if(getSkillType!= null) return getSkillType;
		else throw new RuntimeException("getSkillType not specified in the Configuration.properties file.");		
	}

}