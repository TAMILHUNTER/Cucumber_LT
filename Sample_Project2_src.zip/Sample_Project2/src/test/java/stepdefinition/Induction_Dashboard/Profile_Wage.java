package stepdefinition.Induction_Dashboard;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.java.en.Then;
import object_repository.ObjectsReporsitory;
import object_repository.Skill_Analysis_Objects;
//import object_repository.WorkmenProfile;
import stepdefinition.Screenshot;
import stepdefinition.Webdriver;

public class Profile_Wage {

// Page Factory
	public Profile_Wage() {
		PageFactory.initElements(Webdriver.driver, ObjectsReporsitory.class);
		PageFactory.initElements(Webdriver.driver, Skill_Analysis_Objects.class);
		// PageFactory.initElements(Webdriver.driver, WorkmenProfile.class);
	}

	// Common Imports
	static WebDriverWait wait = new WebDriverWait(Webdriver.driver, 30);
	public static JavascriptExecutor jse = (JavascriptExecutor) Webdriver.driver;

	// **************** Start import methods for step definition
	// ********************

	@Then("^verify Wage details are displayed correctly in profile")
	public static void verify_Wage_details_are_displayed_correctly_in_profile() throws Throwable {
		((JavascriptExecutor) Webdriver.driver).executeScript("arguments[0].click();",Skill_Analysis_Objects.Profile_Wage); // Skill_Analysis_Objects.Profile_Wage.click();
		Thread.sleep(2000);
		if (Skill_Analysis_Objects.Profile_wage_Desc1.getText().equals("No records available.")) {
			System.out.println("Workmen Wage not filled yet Analysed - Wage Details Not Available");
		} else {
			System.out.println("Wage Description  : " + Skill_Analysis_Objects.Profile_wage_Desc1.getText());
			System.out.println("Wage Amount  : " + Skill_Analysis_Objects.Profile_wage_Amount1.getText());
			System.out.println("Wage Type  : " + Skill_Analysis_Objects.Profile_wage_type1.getText());
			System.out.println("----------------------------");
//			System.out.println("Wage Description  : " + Skill_Analysis_Objects.Profile_wage_Desc2.getText());
//			System.out.println("Wage Amount  : " + Skill_Analysis_Objects.Profile_wage_Amount2.getText());
//			System.out.println("Wage Type  : " + Skill_Analysis_Objects.Profile_wage_type2.getText());
//			System.out.println("----------------------------");
			Screenshot.Screenshotforscenario();
		}
	}

}
