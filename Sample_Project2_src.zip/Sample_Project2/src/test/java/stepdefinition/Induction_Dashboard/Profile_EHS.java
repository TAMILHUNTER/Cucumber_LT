package stepdefinition.Induction_Dashboard;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.java.en.Then;
import object_repository.ObjectsReporsitory;
import object_repository.Skill_Analysis_Objects;
//import object_repository.WorkmenProfile;
import stepdefinition.Screenshot;
import stepdefinition.Webdriver;

public class Profile_EHS {

// Page Factory
	public Profile_EHS() {
		PageFactory.initElements(Webdriver.driver, ObjectsReporsitory.class);
		PageFactory.initElements(Webdriver.driver, Skill_Analysis_Objects.class);
		//PageFactory.initElements(Webdriver.driver, WorkmenProfile.class);
	}

	// Common Imports
	static WebDriverWait wait = new WebDriverWait(Webdriver.driver, 30);
	public static JavascriptExecutor jse = (JavascriptExecutor) Webdriver.driver;

	// **************** Start import methods for step definition
	// ********************

	@Then("^verify Skill Description in EHS are displayed correctly in profile")
	public static void verify_Skill_Description_in_EHS_are_displayed_correctly_in_profile() throws Throwable {
		((JavascriptExecutor)Webdriver.driver).executeScript("arguments[0].click();", Skill_Analysis_Objects.Profile_EHS);		//Skill_Analysis_Objects.Profile_EHS.click();
		Thread.sleep(2000);
		if (Skill_Analysis_Objects.Profile_EHS_Skill_desc.getText().equals("No records available.")) {
			System.out.println("Workmen EHS not Completed Yet- Skill Description Details Not Available");
		}

		else {
			System.out.println("Skill Description  : " + Skill_Analysis_Objects.Profile_EHS_Skill_desc.getText());
			System.out.println("----------------------------");
		}
	}

	@Then("^verify job in EHS are displayed correctly in profile")
	public static void verify_job_in_EHS_are_displayed_correctly_in_profile() throws Throwable {
		((JavascriptExecutor)Webdriver.driver).executeScript("arguments[0].click();", Skill_Analysis_Objects.Profile_EHS);		//Skill_Analysis_Objects.Profile_EHS.click();
		Thread.sleep(2000);
		if (Skill_Analysis_Objects.Profile_EHS_Skill_desc.getText().equals("No records available.")) {
			System.out.println("Workmen EHS not Completed Yet- Job Details Not Available");
		}

		else {
			System.out.println("Job  : " + Skill_Analysis_Objects.Profile_EHS_job.getText());
			System.out.println("----------------------------");
		}
	}

	@Then("^verify Training Date in EHS are displayed correctly in profile")
	public static void verify_Training_Date_in_EHS_are_displayed_correctly_in_profile() throws Throwable {
		((JavascriptExecutor)Webdriver.driver).executeScript("arguments[0].click();", Skill_Analysis_Objects.Profile_EHS);		//Skill_Analysis_Objects.Profile_EHS.click();
		Thread.sleep(2000);
		if (Skill_Analysis_Objects.Profile_EHS_Skill_desc.getText().equals("No records available.")) {
			System.out.println("Workmen EHS not Completed Yet- Training Date Details Not Available");
		}

		else {
			System.out.println("Training Date : " + Skill_Analysis_Objects.Profile_EHS_TrainingDate.getText());
			System.out.println("----------------------------");
		}
		Screenshot.Screenshotforscenario();
	}
}
