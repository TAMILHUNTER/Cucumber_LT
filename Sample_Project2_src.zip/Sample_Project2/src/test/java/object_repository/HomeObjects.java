/*package object_repository;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class HomeObjects {
	
	//**HomePage Elements**
	
	@FindBy(how = How.CLASS_NAME, using="user_name")
	public  static WebElement Loggedin_User;
	
	@FindBy(how = How.CLASS_NAME, using="modulemenu")
	public  static WebElement accessBasedMenu;
	
	@FindBy(how = How.XPATH, using="//a[@title='All Menu']")
	public  static WebElement All_Menu;
	
	@FindBy(how = How.XPATH, using="//a[contains(@class,'leafnodelink mat-menu-item')]")
	public  static WebElement Menu_workmenManagementSystem;
	
	@FindBy(how = How.TAG_NAME, using="input")
	public  static WebElement searchMenu;
	
	@FindBy(how = How.ID, using="NotificationiconID")
	public  static WebElement notifications;
	
	@FindBy(how = How.ID, using="profiledropdownbtn")
	public  static WebElement Profiledropdownbtn;
		
	@FindBy(how = How.CLASS_NAME, using="currentdatetime")
	public  static WebElement Date_Time;
		
		
	}
*/