/*package object_repository;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class WMSLandingObjects {
	
	//**HomePage Elements**
	
	@FindBy(how = How.XPATH, using="//span[text()='Dashboard ']")
	public  static WebElement dashboard;
	
	@FindBy(how = How.XPATH, using="//span[text()='Induction ']")
	public  static WebElement induction;
	
	
		
		
	}
*/