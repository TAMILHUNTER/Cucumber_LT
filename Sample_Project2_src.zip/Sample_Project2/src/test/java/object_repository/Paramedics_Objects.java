package object_repository;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class Paramedics_Objects {

		//**Skill Analysis**
	

			
			
						
}
