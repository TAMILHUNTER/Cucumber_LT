package cucumber.examples.java.calculator;

public interface Example {
}
