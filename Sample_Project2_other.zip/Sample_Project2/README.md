# cucumber-demo
This is a demo project for [cucumber framework](https://cucumber.io/) used in a simple java application.

## run project
run `mvn clean install` from the root folder

## Import project in Eclipse

1. Choose Import... -> Existing Maven project
2. Select root folder and press ok -> Finish

## Run cucumber tests

Run RunCukesTest as a simple JUnit test
